using NUnit.Framework;

namespace SeleniumProject.Tests
{
    public class SampleTest
    {
        [Test]
        public void TestMethod()
        {
            Assert.Pass("Your first passing test");
        }
    }
}
