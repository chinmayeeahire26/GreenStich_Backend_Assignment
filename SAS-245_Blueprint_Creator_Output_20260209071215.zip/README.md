# Selenium WebDriver Project

This project is a sample Selenium WebDriver setup using C#. It includes a basic test structure and configuration to get started with automated browser testing.

## Project Structure

- `src/Program.cs`: Main program file.
- `tests/SampleTest.cs`: Sample test file using Selenium WebDriver.

## Getting Started

1. Ensure you have .NET SDK installed.
2. Restore dependencies using `dotnet restore`.
3. Build the project using `dotnet build`.
4. Run tests using `dotnet test`.

## Requirements

- .NET SDK
- Selenium WebDriver

## License

This project is licensed under the MIT License.