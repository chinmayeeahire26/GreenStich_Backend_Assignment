using System;
using OpenQA.Selenium;
using OpenQA.Selenium.Chrome;

namespace SeleniumWebDriverProject
{
    class Program
    {
        static void Main(string[] args)
        {
            // Initialize the ChromeDriver
            IWebDriver driver = new ChromeDriver();

            // Navigate to a website
            driver.Navigate().GoToUrl("https://www.example.com");

            // Perform actions
            Console.WriteLine("Title: " + driver.Title);

            // Close the browser
            driver.Quit();
        }
    }
}