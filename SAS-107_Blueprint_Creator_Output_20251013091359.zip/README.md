# Project: Flipkart Login Automation

This project contains the automation scripts, configuration, and test cases for Flipkart Login functionality.

## Project Structure

```
/tmp/SAS-107_Blueprint_Creator_Output
├── src
│   ├── main
│   │   └── java
│   │       └── LoginAutomation.java
│   └── test
│       └── java
│           └── LoginAutomationTest.java
├── resources
│   ├── config
│   │   └── application-config.properties
│   ├── test-data
│   │   └── login-test-data.json
├── pom.xml
├── .gitignore
```

## Technologies & Tools
- Java
- Maven
- Selenium

## Installation
1. Clone the repository.
2. Navigate into the project directory.
3. Run `mvn install` to install required dependencies.

## Execution
Run the test cases using `mvn test`.