package src.main.java;

public class LoginAutomation {
    public void loginToFlipkart() {
        System.out.println("Automating login to Flipkart.");
    }
}