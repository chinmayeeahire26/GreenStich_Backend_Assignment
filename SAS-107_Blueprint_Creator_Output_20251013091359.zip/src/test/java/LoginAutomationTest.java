package test.java;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;

public class LoginAutomationTest {

    public static void main(String[] args) {
        // Set the path to the ChromeDriver executable
        System.setProperty("webdriver.chrome.driver", "path/to/chromedriver");

        // Initialize WebDriver
        WebDriver driver = new ChromeDriver();

        try {
            // Navigate to Flipkart
            driver.get("https://www.flipkart.com");
            
            // Close the login pop-up
            WebElement closeLoginPopup = driver.findElement(By.xpath("//button[contains(text(),'✕')]"));
            closeLoginPopup.click();

            // Click on the login button
            WebElement loginButton = driver.findElement(By.xpath("//a[contains(text(),'Login')]"));
            loginButton.click();

            // Find and fill out the email/phone number field
            WebElement emailField = driver.findElement(By.xpath("//input[@class='_2IX_2- VJZDxU']"));
            emailField.sendKeys("your_email_or_phone");

            // Find and fill out the password field
            WebElement passwordField = driver.findElement(By.xpath("//input[@type='password']"));
            passwordField.sendKeys("your_password");

            // Submit the login form
            WebElement submitButton = driver.findElement(By.xpath("//button[contains(@type,'submit')]"));
            submitButton.click();

            // Wait for some time to validate the login
            Thread.sleep(5000);

            // Verification logic (Example): Check for user's profile presence post-login
            WebElement userProfile = driver.findElement(By.xpath("//div[contains(text(),'My Account')]"));

            if (userProfile.isDisplayed()) {
                System.out.println("Login successful!");
            } else {
                System.out.println("Login failed!");
            }

        } catch (Exception e) {
            e.printStackTrace();
        } finally {
            // Close the browser
            driver.quit();
        }
    }
}