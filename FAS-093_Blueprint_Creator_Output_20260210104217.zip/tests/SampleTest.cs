using NUnit.Framework;

namespace SeleniumWebDriverProject.Tests
{
    [TestFixture]
    public class SampleTest
    {
        [Test]
        public void TestMethod1()
        {
            Assert.Pass("Your first passing test");
        }
    }
}