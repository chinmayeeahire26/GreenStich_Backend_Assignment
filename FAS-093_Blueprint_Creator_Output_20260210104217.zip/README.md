# Selenium WebDriver C# Project

This project demonstrates the use of Selenium WebDriver with C# for automated browser testing.

## Setup

1. Ensure you have .NET installed on your machine.
2. Restore the necessary packages by running `dotnet restore`.

## Running Tests

Execute the tests using the following command:

```
dotnet test
```

## Project Structure

- `src/Program.cs`: Main entry point for the application.
- `tests/SampleTest.cs`: Contains sample Selenium WebDriver tests.
