using System;
using OpenQA.Selenium;
using OpenQA.Selenium.Chrome;

namespace SeleniumWebDriverProject
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Starting Selenium WebDriver...");
            IWebDriver driver = new ChromeDriver();
            driver.Navigate().GoToUrl("https://www.example.com");
            Console.WriteLine("Title: " + driver.Title);
            driver.Quit();
        }
    }
}