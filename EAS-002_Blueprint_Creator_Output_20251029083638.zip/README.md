# Login to Zepto Automation Project

This project is designed for automating test cases for the Zepto login functionality.
