import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;

public class LoginAutomation {

    public static void main(String[] args) {
        System.setProperty("webdriver.chrome.driver", "path/to/chromedriver");
        
        WebDriver driver = new ChromeDriver();

        try {
            // Navigate to Zepto homepage
            driver.get("https://www.zepto.com");
            
            // Maximize browser window
            driver.manage().window().maximize();

            // Locate and click the login button
            WebElement loginButton = driver.findElement(By.id("loginButtonId"));
            loginButton.click();

            // Input username
            WebElement usernameField = driver.findElement(By.id("usernameFieldId"));
            usernameField.sendKeys("test_user");

            // Input password
            WebElement passwordField = driver.findElement(By.id("passwordFieldId"));
            passwordField.sendKeys("test_password");

            // Click submit button
            WebElement submitButton = driver.findElement(By.id("submitButtonId"));
            submitButton.click();

            // Validate successful login
            WebElement welcomeMessage = driver.findElement(By.id("welcomeMessageId"));
            if (welcomeMessage.isDisplayed()) {
                System.out.println("Login successful!");
            } else {
                System.out.println("Login failed.");
            }

        } catch (Exception e) {
            System.err.println("An error occurred: " + e.getMessage());
        } finally {
            // Quit the driver
            driver.quit();
        }
    }
}