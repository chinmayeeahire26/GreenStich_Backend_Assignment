
// support.js file for Cypress

// Import commands.js using ES2015 syntax:
import './commands';

// Alternatively you can use CommonJS syntax:
// require('./commands')

// Define custom Cypress commands
Cypress.Commands.add('login', (username, password) => {
  cy.visit('/login');
  cy.get('#username').type(username);
  cy.get('#password').type(password);
  cy.get('#loginButton').click();
});

// Sample test case implementation
Cypress.Commands.add('verifyHomePage', () => {
  cy.url().should('include', '/home');
  cy.get('.welcome-banner').should('be.visible');
});

// Place here other supporting utility functions
function supportUtility() {
  // This function can be utilized for various support operations
}

export { supportUtility };
