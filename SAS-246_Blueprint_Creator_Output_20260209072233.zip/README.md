# Project Overview

This project is a Selenium WebDriver automation framework using C#. It includes sample tests and configurations to get started with automated testing.