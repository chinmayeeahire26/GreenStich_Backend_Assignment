using System;

namespace SeleniumWebDriverProject
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Selenium WebDriver C# Project");
        }
    }
}
