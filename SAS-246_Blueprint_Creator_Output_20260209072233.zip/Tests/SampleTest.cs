using NUnit.Framework;
using OpenQA.Selenium;
using OpenQA.Selenium.Chrome;

namespace SeleniumWebDriverProject.Tests
{
    [TestFixture]
    public class SampleTest
    {
        private IWebDriver driver;

        [SetUp]
        public void Setup()
        {
            driver = new ChromeDriver();
        }

        [Test]
        public void TestGoogleSearch()
        {
            driver.Navigate().GoToUrl("https://www.google.com");
            Assert.AreEqual("Google", driver.Title);
        }

        [TearDown]
        public void Teardown()
        {
            driver.Quit();
        }
    }
}
