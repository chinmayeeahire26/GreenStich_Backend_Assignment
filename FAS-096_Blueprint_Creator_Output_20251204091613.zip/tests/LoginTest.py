import requests

def test_login():
    url = "https://zepto.test.app/api/v1/login"
    payload = {"username": "test_user", "password": "password123"}
    response = requests.post(url, json=payload)
    assert response.status_code == 200, "Login failed"