import pytest
from selenium import webdriver

class TestZeptoLogin:
    @pytest.fixture(scope="class")
    def setup(self):
        driver = webdriver.Chrome()
        driver.maximize_window()
        yield driver
        driver.quit()

    @pytest.mark.login
    def test_valid_login(self, setup):
        driver = setup
        driver.get("https://zepto.app")
        driver.find_element("id", "loginButton").click()
        driver.find_element("id", "username").send_keys("valid_user")
        driver.find_element("id", "password").send_keys("valid_password")
        driver.find_element("id", "submit").click()
        success_msg = driver.find_element("id", "successMessage").text
        assert success_msg == "Login successful"
    
    @pytest.mark.login
    def test_invalid_login(self, setup):
        driver = setup
        driver.get("https://zepto.app")
        driver.find_element("id", "loginButton").click()
        driver.find_element("id", "username").send_keys("invalid_user")
        driver.find_element("id", "password").send_keys("invalid_password")
        driver.find_element("id", "submit").click()
        error_msg = driver.find_element("id", "errorMessage").text
        assert error_msg == "Invalid credentials"