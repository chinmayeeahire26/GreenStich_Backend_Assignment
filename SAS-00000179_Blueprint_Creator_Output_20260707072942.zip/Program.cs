using System;
using OpenQA.Selenium;
using OpenQA.Selenium.Chrome;
using OpenQA.Selenium.Support.UI;
using SeleniumExtras.WaitHelpers;

class Program
{
    static void Main(string[] args)
    {
        // Initialize the ChromeDriver (make sure chromedriver.exe is compatible with your Chrome version)
        using (IWebDriver driver = new ChromeDriver())
        {
            // Navigate to Google's homepage
            driver.Navigate().GoToUrl("https://www.google.com");

            // Create a WebDriverWait instance for explicit waits
            WebDriverWait wait = new WebDriverWait(driver, TimeSpan.FromSeconds(10));

            // Wait until the search box is visible and enabled
            IWebElement searchBox = wait.Until(ExpectedConditions.ElementIsVisible(By.Name("q")));

            // Type a query into the search box
            searchBox.SendKeys("Selenium WebDriver with C#");

            // Submit the search form
            searchBox.Submit();

            // Wait until the search results page loads and the results stats element is visible
            wait.Until(ExpectedConditions.ElementIsVisible(By.Id("result-stats")));

            // Extract and print the results stats text
            IWebElement resultsStats = driver.FindElement(By.Id("result-stats"));
            Console.WriteLine("Search completed. Results stats: " + resultsStats.Text);

            // Close the browser
            driver.Quit();
        }
    }
}
