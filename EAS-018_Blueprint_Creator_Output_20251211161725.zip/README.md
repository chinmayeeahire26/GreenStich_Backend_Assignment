# Project Structure
This is the root directory for the automation project.