public class TestScript {
    public void testLogin() {
        System.out.println("Testing login functionality.");
    }
}