using System;
using OpenQA.Selenium;
using OpenQA.Selenium.Chrome;
using OpenQA.Selenium.Support.UI;

namespace SeleniumWebDriverExample
{
    class Program
    {
        static void Main(string[] args)
        {
            // Initialize ChromeDriver with default options
            using IWebDriver driver = new ChromeDriver();

            try
            {
                // Navigate to Google
                driver.Navigate().GoToUrl("https://www.google.com");

                // Wait until the search box is present and visible
                WebDriverWait wait = new WebDriverWait(driver, TimeSpan.FromSeconds(10));
                IWebElement searchBox = wait.Until(drv => drv.FindElement(By.Name("q")));

                // Type the search query
                searchBox.SendKeys("Selenium WebDriver with C#");

                // Submit the search form
                searchBox.Submit();

                // Wait until the search results page loads and results are visible
                wait.Until(drv => drv.Title.ToLower().Contains("selenium webdriver with c#"));

                Console.WriteLine("Search completed successfully.");
            }
            catch (WebDriverTimeoutException ex)
            {
                Console.WriteLine("Timed out waiting for elements: " + ex.Message);
            }
            catch (Exception ex)
            {
                Console.WriteLine("An error occurred: " + ex.Message);
            }
            finally
            {
                // Close the browser
                driver.Quit();
            }
        }
    }
}
