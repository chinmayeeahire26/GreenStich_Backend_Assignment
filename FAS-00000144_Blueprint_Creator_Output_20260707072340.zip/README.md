# Selenium WebDriver Example in C#

This is a simple C# console application demonstrating how to use Selenium WebDriver with ChromeDriver to automate a Google search.

## Prerequisites

- Visual Studio 2022 or later (Community edition is free)
- .NET 6.0 SDK or later

## Setup

1. Open the solution in Visual Studio.
2. Restore NuGet packages (Selenium.WebDriver and Selenium.WebDriver.ChromeDriver are included in the project file).
3. Build the project.

## Running the Application

- Run the application from Visual Studio or via command line:

```bash
dotnet run
```

## What it does

- Opens Google.com in Chrome browser.
- Searches for "Selenium WebDriver with C#".
- Waits for the results page to load.
- Prints a confirmation message.
- Closes the browser.

## Notes

- The ChromeDriver executable is managed automatically by the Selenium.WebDriver.ChromeDriver NuGet package.
- Uses explicit waits for better reliability instead of Thread.Sleep.

## Troubleshooting

- Ensure your Chrome browser version is compatible with the ChromeDriver version.
- If you encounter issues, update the NuGet packages to the latest versions.

---

This project is a basic starting point for Selenium WebDriver automation in C#.