from __future__ import annotations

from copy import deepcopy
from pathlib import Path
from typing import Any, Dict

import os
import yaml


def load_config(path: str | Path) -> Dict[str, Any]:
    """Load YAML configuration."""
    p = Path(path)
    if not p.exists():
        raise FileNotFoundError(f"Config not found: {p}")
    data = yaml.safe_load(p.read_text(encoding="utf-8"))
    if not isinstance(data, dict) or not data:
        raise ValueError("Config is empty or invalid")
    return data


def apply_env_overrides(config: Dict[str, Any]) -> Dict[str, Any]:
    """Apply optional environment variable overrides to the loaded config.

    Supported env vars:
    - BIGBOSS_BASE_URL
    - BIGBOSS_LOGIN_PATH
    - BIGBOSS_USERNAME
    - BIGBOSS_PASSWORD
    """
    cfg = deepcopy(config)

    base_url = os.getenv("BIGBOSS_BASE_URL")
    login_path = os.getenv("BIGBOSS_LOGIN_PATH")
    username = os.getenv("BIGBOSS_USERNAME")
    password = os.getenv("BIGBOSS_PASSWORD")

    cfg.setdefault("app", {})
    cfg.setdefault("auth", {})

    if base_url:
        cfg["app"]["base_url"] = base_url
    if login_path:
        cfg["app"]["login_path"] = login_path
    if username:
        cfg["auth"]["username"] = username
    if password:
        cfg["auth"]["password"] = password

    return cfg
