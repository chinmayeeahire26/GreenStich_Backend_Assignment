from __future__ import annotations

from dataclasses import dataclass

from playwright.sync_api import Page, expect


@dataclass(frozen=True)
class LoginPage:
    """Page object for the BigBoss login page.

    Note:
        Selector values are placeholders and must be replaced with the real
        application's selectors.
    """

    page: Page

    # Placeholder selectors (update these)
    username_input: str = "[data-testid='username']"
    password_input: str = "[data-testid='password']"
    submit_button: str = "[data-testid='login-submit']"

    # Post-login marker: a stable element visible only after successful login
    post_login_marker: str = "[data-testid='dashboard']"

    # Optional marker for login form; used for stronger waits
    login_form_marker: str = "form"

    def goto(self, base_url: str, login_path: str = "/login") -> None:
        """Navigate to login screen."""
        url = f"{base_url.rstrip('/')}{login_path}"
        self.page.goto(url, wait_until="domcontentloaded")
        # Best-effort: ensure login page is ready
        self.page.locator(self.login_form_marker).first.wait_for(state="visible")

    def login(self, username: str, password: str) -> None:
        """Perform login action."""
        self.page.fill(self.username_input, username)
        self.page.fill(self.password_input, password)
        # Click and allow navigation if it occurs
        with self.page.expect_navigation(wait_until="domcontentloaded"):
            self.page.click(self.submit_button)

    def assert_logged_in(self, login_path: str = "/login") -> None:
        """Assert user is logged in.

        We verify:
        - A post-login marker is visible
        - We are not still on the login path (best-effort check)
        """
        expect(self.page.locator(self.post_login_marker)).to_be_visible()
        # If the app uses SPA routing, URL may still contain fragments; keep it lenient.
        expect(self.page).not_to_have_url(lambda url: login_path in url)
