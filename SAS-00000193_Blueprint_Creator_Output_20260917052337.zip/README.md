# SAS-00000193 Blueprint Creator Output

## Scope
Automation skeleton for the requirement: **Login to bigboss**.

## Tech Stack
- **Python 3**
- **pytest** test runner
- **Playwright (sync API)** for UI automation

## Project Layout
- `config/` -> runtime configuration
- `pages/` -> Page Object Model (POM)
- `tests/` -> pytest test cases
- `utils/` -> helpers (config loader, env overrides)

## Setup
```bash
python -m venv .venv
source .venv/bin/activate
pip install -r requirements.txt
playwright install
```

## Configuration
Default config is `config/config.yaml`.

You can override via env vars:
- `BIGBOSS_CONFIG` -> path to a YAML config file
- `BIGBOSS_BASE_URL`, `BIGBOSS_LOGIN_PATH`
- `BIGBOSS_USERNAME`, `BIGBOSS_PASSWORD`
- `BIGBOSS_HEADLESS` (`true|false`)

Example:
```bash
export BIGBOSS_BASE_URL="https://your-bigboss-host"
export BIGBOSS_USERNAME="alice"
export BIGBOSS_PASSWORD="secret"
pytest -q
```

## Run
```bash
pytest -q
```

## Notes
- Selectors in `pages/login_page.py` are placeholders; replace with actual app selectors.
- The login assertion checks for a post-login marker and also verifies the page is not still on `/login`.
