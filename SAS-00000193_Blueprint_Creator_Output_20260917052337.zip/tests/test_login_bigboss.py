from __future__ import annotations

from pages.login_page import LoginPage


def test_login_to_bigboss(page, config):
    """Test Case: Login to bigboss."""
    login = LoginPage(page)
    login.goto(config["app"]["base_url"], config["app"].get("login_path", "/login"))
    login.login(config["auth"]["username"], config["auth"]["password"])
    login.assert_logged_in(login_path=config["app"].get("login_path", "/login"))
