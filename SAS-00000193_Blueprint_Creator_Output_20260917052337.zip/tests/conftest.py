from __future__ import annotations

import os
from typing import Dict, Any

import pytest
from playwright.sync_api import Browser, BrowserContext, Page, sync_playwright

from utils.config import load_config, apply_env_overrides


@pytest.fixture(scope="session")
def config() -> Dict[str, Any]:
    """Load config once per test session."""
    path = os.getenv("BIGBOSS_CONFIG", "config/config.yaml")
    cfg = load_config(path)
    return apply_env_overrides(cfg)


@pytest.fixture(scope="session")
def browser(config) -> Browser:
    """Create one browser per session."""
    headless_env = os.getenv("BIGBOSS_HEADLESS")
    headless = config.get("browser", {}).get("headless", True)
    if headless_env is not None:
        headless = headless_env.strip().lower() in {"1", "true", "yes", "y"}

    with sync_playwright() as p:
        br = p.chromium.launch(headless=headless)
        yield br
        br.close()


@pytest.fixture()
def context(browser: Browser, config) -> BrowserContext:
    viewport = (config.get("browser", {}) or {}).get("viewport") or {"width": 1280, "height": 720}
    ctx = browser.new_context(viewport=viewport)
    yield ctx
    ctx.close()


@pytest.fixture()
def page(context: BrowserContext, config) -> Page:
    """Provide a Playwright page per test."""
    pg = context.new_page()
    pg.set_default_navigation_timeout(int(config["timeouts"]["navigation_ms"]))
    pg.set_default_timeout(int(config["timeouts"]["action_ms"]))
    yield pg
    pg.close()
