// Automation script for Zepto login
function loginToZepto() {
    console.log('Logging in...');
}
