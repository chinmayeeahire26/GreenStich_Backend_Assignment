# Project README

This project is set up for Selenium WebDriver using C#. It includes a sample test script and configuration settings for running tests on the Chrome browser. Ensure you have the necessary dependencies installed and configured before running the tests.