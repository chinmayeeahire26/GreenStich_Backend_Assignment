// Main test script for Selenium WebDriver in C#

using OpenQA.Selenium;
using OpenQA.Selenium.Chrome;
using NUnit.Framework;

namespace SeleniumTests
{
    public class MainTest
    {
        private IWebDriver driver;

        [SetUp]
        public void StartBrowser()
        {
            var options = new ChromeOptions();
            options.AddArgument("--headless");
            driver = new ChromeDriver(options);
        }

        [Test]
        public void TestPageTitle()
        {
            driver.Navigate().GoToUrl("https://www.example.com");
            Assert.AreEqual("Example Domain", driver.Title);
        }

        [TearDown]
        public void CloseBrowser()
        {
            driver.Quit();
        }
    }
}