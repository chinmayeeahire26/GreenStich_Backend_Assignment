# Intune Login Automation (Playwright)

This project contains a Playwright test for logging into Microsoft Intune (Intune portal).

## Prerequisites
- Node.js 18+

## Setup
```bash
npm install
npx playwright install --with-deps
```

## Environment
Create a `.env` file:
```ini
INTUNE_URL=https://intune.microsoft.com
INTUNE_USERNAME=your.user@tenant.onmicrosoft.com
INTUNE_PASSWORD=yourPassword
INTUNE_TENANT_HINT=optionalTenantHint
```

## Run
```bash
npm test
```

## Notes
The Microsoft login flow can vary (MFA, conditional access). This sample handles the common username/password flow and will fail with a clear error message if interactive steps are required.
