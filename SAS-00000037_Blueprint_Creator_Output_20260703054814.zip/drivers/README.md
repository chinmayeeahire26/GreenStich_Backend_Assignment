# Drivers Folder

Place the ChromeDriver executable here. Download the appropriate version for your OS from https://sites.google.com/chromium.org/driver/ and rename it to 'chromedriver'.