using System;
using NUnit.Framework;
using OpenQA.Selenium;
using OpenQA.Selenium.Chrome;

namespace SeleniumTest
{
    [TestFixture]
    public class SampleTest
    {
        private IWebDriver driver;

        [SetUp]
        public void Setup()
        {
            // Initialize the ChromeDriver
            driver = new ChromeDriver();
        }

        [Test]
        public void AmazonLoginTest()
        {
            // Navigate to Amazon
            driver.Navigate().GoToUrl("https://www.amazon.com");

            // Click on the 'Sign in' button
            IWebElement signInButton = driver.FindElement(By.Id("nav-link-accountList"));
            signInButton.Click();

            // Enter email
            IWebElement emailField = driver.FindElement(By.Id("ap_email"));
            emailField.SendKeys("your-email@example.com");

            // Click on 'Continue'
            IWebElement continueButton = driver.FindElement(By.Id("continue"));
            continueButton.Click();

            // Enter password
            IWebElement passwordField = driver.FindElement(By.Id("ap_password"));
            passwordField.SendKeys("your-password");

            // Click on 'Sign in'
            IWebElement loginButton = driver.FindElement(By.Id("signInSubmit"));
            loginButton.Click();

            // Assert that the login was successful by checking the presence of an element unique to logged-in users
            IWebElement accountElement = driver.FindElement(By.Id("nav-link-accountList-nav-line-1"));
            Assert.IsTrue(accountElement.Text.Contains("Hello"));
        }

        [TearDown]
        public void Teardown()
        {
            // Close the browser
            driver.Quit();
        }
    }
}
