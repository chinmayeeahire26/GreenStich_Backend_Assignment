namespace ProjectVariables {
    public class EnvironmentVariables {
        // Define environment variables here
    }
}