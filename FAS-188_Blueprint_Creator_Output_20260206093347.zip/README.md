# Project: Selenium Web Drive with C#

This project contains the setup for Selenium Web Drive using C#.

## Structure

- **C# Settings**: Contains configuration files for C#.
- **Variables**: Contains environment and global variables.
- **Sample Test Script**: Contains sample test scripts for Selenium.
