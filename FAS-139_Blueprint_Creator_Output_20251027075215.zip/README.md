# Project FAS-139 Blueprint Creator

This project contains the automation setup for 'Login to Tosca'.

## Project Structure
- **src/**: Contains source code
- **tests/**: Contains test scripts
- **configs/**: Configuration files for the project
- **logs/**: Log files generated during execution

## Getting Started
The project follows the blueprint guidelines to ensure accurate implementation of automation.