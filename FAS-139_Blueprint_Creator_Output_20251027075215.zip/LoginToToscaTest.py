import pytest
from selenium import webdriver

class TestLoginToTosca:
    def setup_method(self):
        """Setup method to initialize the webdriver"""
        self.driver = webdriver.Chrome()
        self.driver.maximize_window()

    def teardown_method(self):
        """Teardown method to quit the webdriver"""
        self.driver.quit()

    def test_login_tosca(self):
        """Method to login to Tosca application"""
        self.driver.get("https://tosca.example.com/login")
        self.driver.find_element_by_id("username").send_keys("testUser")
        self.driver.find_element_by_id("password").send_keys("testPassword")
        self.driver.find_element_by_id("loginButton").click()
        assert "Dashboard" in self.driver.title

