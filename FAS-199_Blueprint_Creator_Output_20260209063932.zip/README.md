# Selenium Web Driver Project

This project is set up for Selenium Web Driver using C#.

## Project Structure

- `src/`: Contains the source code.
- `tests/`: Contains the test scripts.
- `config/`: Contains configuration files.
