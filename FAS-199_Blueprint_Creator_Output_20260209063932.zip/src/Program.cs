using System;
using OpenQA.Selenium;
using OpenQA.Selenium.Chrome;

namespace SeleniumTest
{
    class Program
    {
        static void Main(string[] args)
        {
            // Create a new instance of the Chrome driver
            IWebDriver driver = new ChromeDriver();

            // Navigate to Google
            driver.Navigate().GoToUrl("http://www.google.com");

            // Find the search box using its name attribute
            IWebElement query = driver.FindElement(By.Name("q"));

            // Enter text into the search box
            query.SendKeys("Selenium WebDriver");

            // Submit the search form
            query.Submit();

            // Close the browser
            driver.Quit();
        }
    }
}