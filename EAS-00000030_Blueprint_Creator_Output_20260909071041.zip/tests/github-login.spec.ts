import { test } from '@playwright/test';
import { getEnv } from '../src/config/env';
import { GitHubLoginPage } from '../src/pages/GitHubLoginPage';

test.describe('GitHub - Login', () => {
  test('login to github', async ({ page }) => {
    const env = getEnv();

    const loginPage = new GitHubLoginPage(page);
    await loginPage.gotoLogin();
    await loginPage.login(env.username, env.password);
    await loginPage.assertLoggedIn();
  });
});
