# EAS-00000030 - GitHub Login Automation (Playwright)

## Setup
```bash
npm i
npx playwright install
```

## Configure credentials
- Copy `.env.example` to `.env` and set `GITHUB_USERNAME` and `GITHUB_PASSWORD`.

## Run
```bash
npm test
npm run test:headed
npm run report
```

## Notes
- This project is a ready structure for generating automation methods for the test case: **login to github**.
