export type Env = {
  baseUrl: string;
  username: string;
  password: string;
};

function requireEnv(name: string): string {
  const v = process.env[name];
  if (!v) throw new Error(`Missing required env var: ${name}`);
  return v;
}

export function getEnv(): Env {
  return {
    baseUrl: process.env.BASE_URL || 'https://github.com',
    username: requireEnv('GITHUB_USERNAME'),
    password: requireEnv('GITHUB_PASSWORD'),
  };
}
