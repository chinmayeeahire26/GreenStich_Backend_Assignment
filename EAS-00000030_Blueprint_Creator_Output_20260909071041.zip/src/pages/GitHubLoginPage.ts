import { expect, Page } from '@playwright/test';

export class GitHubLoginPage {
  readonly page: Page;

  constructor(page: Page) {
    this.page = page;
  }

  async gotoLogin(): Promise<void> {
    await this.page.goto('/login');
    await expect(this.page).toHaveURL(/\/login/);
  }

  async login(username: string, password: string): Promise<void> {
    await this.page.getByLabel('Username or email address').fill(username);
    await this.page.getByLabel('Password').fill(password);
    await this.page.getByRole('button', { name: 'Sign in' }).click();
  }

  async assertLoggedIn(): Promise<void> {
    await expect(this.page.getByRole('link', { name: 'Dashboard' })).toBeVisible({ timeout: 15000 });
  }
}
