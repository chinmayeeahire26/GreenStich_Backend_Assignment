# Project Overview

This project contains automated tests using Selenium WebDriver with C#.