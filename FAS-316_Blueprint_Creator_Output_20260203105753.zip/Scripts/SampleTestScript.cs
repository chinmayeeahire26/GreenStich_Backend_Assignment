using OpenQA.Selenium;
using OpenQA.Selenium.Chrome;

namespace SampleTests
{
    public class SampleTest
    {
        public void TestLogin()
        {
            IWebDriver driver = new ChromeDriver();
            driver.Navigate().GoToUrl("http://example.com/login");
            // Add login test steps here
            driver.Quit();
        }
    }
}