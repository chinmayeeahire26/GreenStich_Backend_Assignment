# SAS-00000406 UI Automation

## Overview
UI automation project (Maven + JUnit 5 + Selenium) containing the test case:
- Verify that the application does not allow login with incorrect username and password.

## Prerequisites
- Java 17+
- Maven 3.8+

## Configure
Update `src/test/resources/config.properties` with your application URL and settings.

## Run
```bash
mvn test
```
