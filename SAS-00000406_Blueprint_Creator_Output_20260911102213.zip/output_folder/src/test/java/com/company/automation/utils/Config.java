package com.company.automation.utils;

import java.io.IOException;
import java.io.InputStream;
import java.util.Properties;

public final class Config {

    private static final Properties PROPS = new Properties();

    static {
        try (InputStream is = Config.class.getClassLoader().getResourceAsStream("config.properties")) {
            if (is == null) {
                throw new IllegalStateException("config.properties not found on classpath");
            }
            PROPS.load(is);
        } catch (IOException e) {
            throw new RuntimeException("Failed to load config.properties", e);
        }
    }

    private Config() {
    }

    private static String get(String key) {
        String sys = System.getProperty(key);
        if (sys != null && !sys.isBlank()) return sys;
        String env = System.getenv(key);
        if (env != null && !env.isBlank()) return env;
        return PROPS.getProperty(key);
    }

    public static String baseUrl() {
        return require("baseUrl");
    }

    public static String browser() {
        String v = get("browser");
        return (v == null || v.isBlank()) ? "chrome" : v.trim();
    }

    public static boolean headless() {
        String v = get("headless");
        return v != null && v.trim().equalsIgnoreCase("true");
    }

    public static int timeoutSeconds() {
        String v = get("timeoutSeconds");
        if (v == null || v.isBlank()) return 10;
        return Integer.parseInt(v.trim());
    }

    public static String loginPath() {
        String v = get("loginPath");
        return (v == null || v.isBlank()) ? "/login" : v.trim();
    }

    public static String loginErrorSelector() {
        String v = get("loginErrorSelector");
        return (v == null || v.isBlank()) ? ".error, .alert, [role='alert']" : v.trim();
    }

    private static String require(String key) {
        String v = get(key);
        if (v == null || v.isBlank()) {
            throw new IllegalStateException("Missing required config value: " + key);
        }
        return v.trim();
    }
}
