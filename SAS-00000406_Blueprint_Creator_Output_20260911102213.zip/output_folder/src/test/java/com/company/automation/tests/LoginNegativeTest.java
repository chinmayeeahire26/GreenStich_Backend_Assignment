package com.company.automation.tests;

import com.company.automation.pages.LoginPage;
import com.company.automation.utils.Config;
import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Test;

public class LoginNegativeTest extends BaseTest {

    /**
     * Test: Verify that the application does not allow login with incorrect username and password.
     * Action: Navigate to login page, enter invalid credentials, click login.
     * Expected: Error message indicating invalid login credentials is displayed.
     */
    @Test
    public void shouldNotAllowLoginWithInvalidUsernameAndPassword() {
        String loginUrl = Config.baseUrl() + Config.loginPath();

        LoginPage loginPage = new LoginPage(driver)
                .open(loginUrl)
                .enterUsername("invalidUser")
                .enterPassword("wrongPassword")
                .clickLogin();

        Assertions.assertTrue(
                loginPage.isInvalidCredentialsErrorDisplayed(),
                "Expected an error message indicating invalid login credentials to be displayed"
        );
    }
}
