package com.company.automation.pages;

import com.company.automation.utils.Config;
import com.company.automation.utils.Waiter;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

public class LoginPage {

    private final WebDriver driver;

    // Default locators (commonly used). Adjust for your AUT.
    private final By usernameInput = By.cssSelector("input[name='username'], input#username, input[type='email']");
    private final By passwordInput = By.cssSelector("input[name='password'], input#password, input[type='password']");
    private final By loginButton = By.cssSelector("button[type='submit'], button#login, input[type='submit']");

    public LoginPage(WebDriver driver) {
        this.driver = driver;
    }

    public LoginPage open(String url) {
        driver.get(url);
        // Wait for page to be ready enough to interact
        Waiter.visible(driver, usernameInput, Config.timeoutSeconds());
        return this;
    }

    public LoginPage enterUsername(String username) {
        WebElement el = Waiter.visible(driver, usernameInput, Config.timeoutSeconds());
        el.clear();
        el.sendKeys(username);
        return this;
    }

    public LoginPage enterPassword(String password) {
        WebElement el = Waiter.visible(driver, passwordInput, Config.timeoutSeconds());
        el.clear();
        el.sendKeys(password);
        return this;
    }

    public LoginPage clickLogin() {
        Waiter.clickable(driver, loginButton, Config.timeoutSeconds()).click();
        return this;
    }

    public boolean isInvalidCredentialsErrorDisplayed() {
        By error = By.cssSelector(Config.loginErrorSelector());
        try {
            WebElement el = Waiter.visible(driver, error, Config.timeoutSeconds());
            String text = el.getText() == null ? "" : el.getText().trim().toLowerCase();
            // We allow any visible error element, but prefer a message with relevant semantics.
            return el.isDisplayed() && (text.contains("invalid") || text.contains("incorrect") || text.contains("credential") || text.length() > 0);
        } catch (Exception e) {
            return false;
        }
    }
}
