package com.company.automation.utils;

import io.github.bonigarcia.wdm.WebDriverManager;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;

public final class DriverFactory {

    private DriverFactory() {
    }

    public static WebDriver createDriver(String browser, boolean headless) {
        // For this blueprint, we keep it minimal (Chrome only). Extend if needed.
        if (browser == null || browser.isBlank() || browser.equalsIgnoreCase("chrome")) {
            WebDriverManager.chromedriver().setup();
            ChromeOptions options = new ChromeOptions();
            if (headless) {
                options.addArguments("--headless=new");
            }
            options.addArguments("--no-sandbox");
            options.addArguments("--disable-dev-shm-usage");
            return new ChromeDriver(options);
        }
        throw new IllegalArgumentException("Unsupported browser: " + browser + ". Only 'chrome' is supported in this project.");
    }
}
