# Flipkart Automation Project

This project contains the automation scripts for testing the Flipkart login functionality.