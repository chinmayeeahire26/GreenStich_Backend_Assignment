using OpenQA.Selenium;
using OpenQA.Selenium.Chrome;
using NUnit.Framework;

namespace SeleniumTests
{
    public class SampleTest
    {
        private IWebDriver driver;

        [SetUp]
        public void Setup()
        {
            driver = new ChromeDriver();
        }

        [Test]
        public void TestGoogleSearch()
        {
            driver.Navigate().GoToUrl("https://www.google.com");
            var searchBox = driver.FindElement(By.Name("q"));
            searchBox.SendKeys("Selenium WebDriver");
            searchBox.Submit();
            Assert.IsTrue(driver.Title.Contains("Selenium WebDriver"));
        }

        [TearDown]
        public void Teardown()
        {
            driver.Quit();
        }
    }
}