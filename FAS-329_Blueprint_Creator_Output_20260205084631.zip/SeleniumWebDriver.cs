// Selenium WebDriver setup
using OpenQA.Selenium;
using OpenQA.Selenium.Chrome;

namespace SeleniumWebDriver
{
    public class WebDriverSetup
    {
        public IWebDriver Driver { get; private set; }

        public WebDriverSetup()
        {
            Driver = new ChromeDriver();
        }
    }
}