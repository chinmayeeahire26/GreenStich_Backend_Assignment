import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;

public class ZeptoLoginTest {
    private WebDriver driver;

    public void setUp() {
        System.setProperty("webdriver.chrome.driver", "/path/to/chromedriver");
        driver = new ChromeDriver();
    }

    public void loginTest() {
        driver.get("https://www.zepto.com/login");

        WebElement usernameField = driver.findElement(By.id("username"));
        WebElement passwordField = driver.findElement(By.id("password"));
        WebElement loginButton = driver.findElement(By.id("loginButton"));

        usernameField.sendKeys("myUsername");
        passwordField.sendKeys("myPassword");
        loginButton.click();
    }

    public void tearDown() {
        driver.quit();
    }

    public static void main(String[] args) {
        ZeptoLoginTest test = new ZeptoLoginTest();
        test.setUp();
        test.loginTest();
        test.tearDown();
    }
}
