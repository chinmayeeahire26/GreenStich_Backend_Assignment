using System;
using OpenQA.Selenium;
using OpenQA.Selenium.Chrome;

namespace LoginTest
{
    class Program
    {
        // Variables (Settings)
        static string url = "https://www.example.com/login";
        static string usernameFieldId = "username";
        static string passwordFieldId = "password";
        static string loginButtonId = "loginButton";
        static string username = "testuser";
        static string password = "testpassword";

        static void Main(string[] args)
        {
            IWebDriver driver = new ChromeDriver();
            try
            {
                driver.Navigate().GoToUrl(url);
                driver.Manage().Window.Maximize();

                IWebElement usernameField = driver.FindElement(By.Id(usernameFieldId));
                usernameField.SendKeys(username);

                IWebElement passwordField = driver.FindElement(By.Id(passwordFieldId));
                passwordField.SendKeys(password);

                IWebElement loginButton = driver.FindElement(By.Id(loginButtonId));
                loginButton.Click();

                System.Threading.Thread.Sleep(3000); // Wait to observe result

                Console.WriteLine("Login test completed successfully.");
            }
            catch (NoSuchElementException e)
            {
                Console.WriteLine("Element not found: " + e.Message);
            }
            catch (Exception e)
            {
                Console.WriteLine("Test failed: " + e.Message);
            }
            finally
            {
                driver.Quit();
            }
        }
    }
}
