# SAS-00000388 Automation Project

This project contains automation scripts for testing login to ChatGPT.