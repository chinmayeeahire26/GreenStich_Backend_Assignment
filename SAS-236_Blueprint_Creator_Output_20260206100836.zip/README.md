# Project Overview
This project is structured for Selenium WebDriver automation using C#.
