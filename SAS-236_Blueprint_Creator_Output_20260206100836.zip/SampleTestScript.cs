using System;
using OpenQA.Selenium;
using OpenQA.Selenium.Chrome;

namespace SeleniumTest
{
    class SampleTestScript
    {
        static void Main(string[] args)
        {
            // Create a new instance of the Chrome driver
            IWebDriver driver = new ChromeDriver();

            // Navigate to Google
            driver.Navigate().GoToUrl("http://www.google.com");

            // Find the search box using its name attribute
            IWebElement searchBox = driver.FindElement(By.Name("q"));

            // Enter text into the search box
            searchBox.SendKeys("Selenium WebDriver");

            // Submit the search
            searchBox.Submit();

            // Close the browser
            driver.Quit();
        }
    }
}