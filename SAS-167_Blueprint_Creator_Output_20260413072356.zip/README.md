# Login Automation Project

This project contains Selenium WebDriver automation code in Java to perform login operations on the specified application.

## Project Structure

- `src/main/java/com/example/automation/LoginAutomation.java`: Main automation code.
- `pom.xml`: Maven project file with Selenium and WebDriverManager dependencies.

## How to Run

1. Update the ChromeDriver path in `LoginAutomation.java` or use WebDriverManager.
2. Build the project using Maven: `mvn clean compile exec:java -Dexec.mainClass=com.example.automation.LoginAutomation`

## Notes

- Replace the placeholder ChromeDriver path with the actual path.
- Ensure ChromeDriver version matches your Chrome browser version.
