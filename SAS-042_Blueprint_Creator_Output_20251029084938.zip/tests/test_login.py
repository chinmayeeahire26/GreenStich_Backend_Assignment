import pytest
from selenium import webdriver
from selenium.webdriver.common.by import By
from selenium.webdriver.common.keys import Keys

class TestLoginZepto:

    def setup_method(self):
        """Set up method to initialize the browser"""
        self.driver = webdriver.Chrome()
        self.driver.maximize_window()
        self.driver.get("https://www.zepto.io/login")

    def teardown_method(self):
        """Tear down method to close the browser"""
        self.driver.quit()

    def test_valid_login(self):
        """Test valid login functionality"""
        username_field = self.driver.find_element(By.ID, "username")
        password_field = self.driver.find_element(By.ID, "password")
        login_button = self.driver.find_element(By.ID, "login-button")

        # Input credentials
        username_field.send_keys("test_user")
        password_field.send_keys("test_password")

        # Click the login button
        login_button.click()

        # Verify login success by checking redirect or user-specific element
        assert "Dashboard" in self.driver.title
        print("Successfully logged in!")

    def test_invalid_login(self):
        """Test invalid login functionality"""
        username_field = self.driver.find_element(By.ID, "username")
        password_field = self.driver.find_element(By.ID, "password")
        login_button = self.driver.find_element(By.ID, "login-button")

        # Input invalid credentials
        username_field.send_keys("wrong_user")
        password_field.send_keys("wrong_password")

        # Click the login button
        login_button.click()

        # Verify login failure by checking error element visibility
        error_message = self.driver.find_element(By.ID, "error-message")
        assert error_message.is_displayed()
        print("Invalid login attempt logged correctly!")

if __name__ == "__main__":
    pytest.main([__file__])