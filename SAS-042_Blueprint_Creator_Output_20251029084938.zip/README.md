Project for Zepto Login Automation
This project contains test cases, configurations, and scripts for Zepto Login automation as per blueprint guidelines.