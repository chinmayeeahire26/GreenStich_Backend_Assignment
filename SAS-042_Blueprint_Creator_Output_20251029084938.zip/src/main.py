def main():
    print('Zepto Login Automation script')
if __name__ == '__main__':
    main()