# Selenium WebDriver C# Sample Project

This project contains a sample Selenium WebDriver test script written in C# using NUnit framework.

## Structure
- tests/: Contains the sample test script.
- SeleniumTests.csproj: Project file with dependencies.

## Usage
Run the tests using a compatible test runner like Visual Studio Test Explorer or dotnet test CLI.
