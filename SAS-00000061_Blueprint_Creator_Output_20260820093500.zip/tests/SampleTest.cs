using NUnit.Framework;
using OpenQA.Selenium;
using OpenQA.Selenium.Chrome;

namespace SeleniumTests
{
    public class SampleTest
    {
        private IWebDriver driver;

        [SetUp]
        public void Setup()
        {
            driver = new ChromeDriver();
        }

        [Test]
        public void TestGoogleSearch()
        {
            driver.Navigate().GoToUrl("https://www.google.com");
            IWebElement query = driver.FindElement(By.Name("q"));
            query.SendKeys("Selenium WebDriver");
            query.Submit();
            Assert.IsTrue(driver.Title.Contains("Selenium WebDriver"));
        }

        [TearDown]
        public void TearDown()
        {
            driver.Quit();
        }
    }
}
