# EAS-00000046 Bigboss Login Automation

## Overview
Playwright-based UI automation for the test case: **Login to Bigboss**.

## Tech stack
- Playwright Test (TypeScript)
- dotenv for environment configuration

## Prerequisites
- Node.js 18+

## Setup
```bash
npm install
cp .env.example .env
# edit .env with real BASE_URL and credentials
```

## Run tests
```bash
npm test
```

Headed mode:
```bash
npm run test:headed
```

UI mode:
```bash
npm run test:ui
```

Report:
```bash
npm run report
```

## Configuration
- `BASE_URL`: Base URL of the Bigboss application (e.g., https://bigboss.example.com)
- `BIGBOSS_USERNAME` / `BIGBOSS_PASSWORD`: credentials to log in

## Selector mapping
Selectors are centralized in `config/selectors.json`. Update these selectors to match your application under test.

## Notes
- The login route defaults to `/login` in `LoginPage.goto()`. If your application uses a different route, update it.
- The success criteria uses a `postLoginMarker` selector. Update it to a reliable element visible only after login.
