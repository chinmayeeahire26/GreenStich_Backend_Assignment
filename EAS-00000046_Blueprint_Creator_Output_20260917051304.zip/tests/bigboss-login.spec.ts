import { test } from '@playwright/test';
import { LoginPage } from '../src/pages/LoginPage';
import { assertEnvForLogin, env } from '../src/config/env';
import { expectVisible } from '../src/utils/assertions';

test.describe('Bigboss - Login', () => {
  test('Login to Bigboss', async ({ page }) => {
    assertEnvForLogin();

    const loginPage = new LoginPage(page);

    await loginPage.goto();
    await loginPage.assertOnLoginPage();
    await loginPage.login(env.username, env.password);

    // Validate successful login (update selector/text per AUT)
    await expectVisible(loginPage.postLoginMarker, 'Expected a post-login marker to be visible');
  });
});
