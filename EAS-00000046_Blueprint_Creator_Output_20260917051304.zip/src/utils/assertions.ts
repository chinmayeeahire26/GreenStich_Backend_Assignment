import { expect, Locator, Page } from '@playwright/test';

export async function expectVisible(locator: Locator, message?: string) {
  await expect(locator, message).toBeVisible();
}

export async function expectHidden(locator: Locator, message?: string) {
  await expect(locator, message).toBeHidden();
}

export async function expectUrlContains(page: Page, partial: string, message?: string) {
  await expect(page, message).toHaveURL(new RegExp(partial.replace(/[.*+?^${}()|[\]\\]/g, '\\$&')));
}
