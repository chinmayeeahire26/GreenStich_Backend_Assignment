export const env = {
  baseURL: process.env.BASE_URL || 'https://example.com',
  username: process.env.BIGBOSS_USERNAME || '',
  password: process.env.BIGBOSS_PASSWORD || '',
  /**
   * Optional override for applications where login route is not `/login`.
   * Example: `/auth/login`
   */
  loginPath: process.env.BIGBOSS_LOGIN_PATH || '/login',
};

export function assertEnvForLogin() {
  // Fail fast with a clear error if credentials are missing.
  if (!env.username || !env.password) {
    throw new Error(
      'Missing BIGBOSS_USERNAME or BIGBOSS_PASSWORD. Set them in your environment or in a local .env file.'
    );
  }
}
