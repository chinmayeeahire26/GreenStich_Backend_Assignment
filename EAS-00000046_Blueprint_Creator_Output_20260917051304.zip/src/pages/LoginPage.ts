import { expect, Locator, Page } from '@playwright/test';
import selectors from '../../config/selectors.json';
import { env } from '../config/env';

export class LoginPage {
  readonly page: Page;
  readonly username: Locator;
  readonly password: Locator;
  readonly submit: Locator;
  readonly postLoginMarker: Locator;
  readonly errorBanner: Locator;

  constructor(page: Page) {
    this.page = page;
    this.username = page.locator(selectors.login.username);
    this.password = page.locator(selectors.login.password);
    this.submit = page.locator(selectors.login.submit);
    this.postLoginMarker = page.locator(selectors.login.postLoginMarker);
    this.errorBanner = page.locator(selectors.login.errorBanner);
  }

  // methodName: goto
  async goto() {
    // Uses optional env.loginPath override; defaults to /login
    await this.page.goto(env.loginPath);
  }

  // methodName: login
  async login(username: string, password: string) {
    await this.username.fill(username);
    await this.password.fill(password);

    // Click + wait for navigation/network to settle where applicable.
    await Promise.all([
      // Some apps don't do a full navigation; the wait below is resilient.
      this.page.waitForLoadState('networkidle').catch(() => void 0),
      this.submit.click(),
    ]);
  }

  // methodName: assertOnLoginPage
  async assertOnLoginPage() {
    await expect(this.username, 'Expected username field to be visible on login page').toBeVisible();
    await expect(this.password, 'Expected password field to be visible on login page').toBeVisible();
    await expect(this.submit, 'Expected submit button to be visible on login page').toBeVisible();
  }
}
