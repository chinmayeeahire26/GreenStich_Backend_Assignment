# SAS-00000378_Blueprint_Creator_Output

This project contains a Selenium WebDriver automation script in Java that performs login and navigation actions on the specified web application.

## Project Structure

- src/main/java/com/automation/SampleAutomation.java: Main automation script.

## Prerequisites

- Java JDK installed
- Selenium WebDriver dependencies
- ChromeDriver executable path set correctly in the script

## How to Run

Compile and run the SampleAutomation.java class after setting the correct path to your ChromeDriver executable.
