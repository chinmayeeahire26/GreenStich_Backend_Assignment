# Selenium WebDriver C# Sample Project

This project contains a sample Selenium WebDriver test script written in C#.

## Project Structure

- src/: Source code
- tests/: Automated test scripts
- packages.config: NuGet package configuration
- README.md: Project overview

## How to run

Use Visual Studio or dotnet CLI to build and run the tests.
