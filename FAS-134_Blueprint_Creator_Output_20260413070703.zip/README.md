# Login Automation Project

This project contains Selenium WebDriver automation code in Java to perform login to the application https://kairos-capgemini.azurewebsites.net/login.

## Project Structure

- `pom.xml`: Maven project file with Selenium dependency.
- `src/main/java/com/example/LoginAutomation.java`: Java class with Selenium automation code.

## Setup

1. Replace `path/to/chromedriver` in `LoginAutomation.java` with the actual path to your ChromeDriver executable.
2. Build the project using Maven.
3. Run the `LoginAutomation` class to execute the login automation.

## Notes

- The code performs login steps including clicking images, entering username and password, selecting portfolio, and logging out.
- Ensure ChromeDriver version matches your installed Chrome browser.
