using System;
using OpenQA.Selenium;
using OpenQA.Selenium.Chrome;
using OpenQA.Selenium.Support.UI;

namespace login
{
    class Program
    {
        static void Main(string[] args)
        {
            // Initialize ChromeDriver (make sure ChromeDriver executable matches your Chrome version)
            using (IWebDriver driver = new ChromeDriver())
            {
                WebDriverWait wait = new WebDriverWait(driver, TimeSpan.FromSeconds(10));

                // Navigate to a sample login page
                driver.Navigate().GoToUrl("https://the-internet.herokuapp.com/login");

                // Wait until the username field is present
                wait.Until(d => d.FindElement(By.Id("username")));

                // Find username and password fields
                IWebElement usernameField = driver.FindElement(By.Id("username"));
                IWebElement passwordField = driver.FindElement(By.Id("password"));

                // Enter credentials
                usernameField.SendKeys("tomsmith");
                passwordField.SendKeys("SuperSecretPassword!");

                // Find and click the login button
                IWebElement loginButton = driver.FindElement(By.CssSelector("button[type='submit']"));
                loginButton.Click();

                // Wait for the success message
                wait.Until(d => d.FindElement(By.CssSelector(".flash.success")));

                Console.WriteLine("Login successful!");

                // Close the browser
                driver.Quit();
            }
        }
    }
}
