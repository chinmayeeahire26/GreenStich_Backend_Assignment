using OpenQA.Selenium;
using OpenQA.Selenium.Chrome;
using System;

namespace SeleniumWebDriverLogin
{
    class Program
    {
        static void Main(string[] args)
        {
            // Initialize the ChromeDriver
            IWebDriver driver = new ChromeDriver();
            try
            {
                // Navigate to the login page
                driver.Navigate().GoToUrl("https://example.com/login");

                // Find the username and password fields and login button
                IWebElement usernameField = driver.FindElement(By.Id("username"));
                IWebElement passwordField = driver.FindElement(By.Id("password"));
                IWebElement loginButton = driver.FindElement(By.Id("loginButton"));

                // Enter credentials
                usernameField.SendKeys("your_username");
                passwordField.SendKeys("your_password");

                // Click login
                loginButton.Click();

                // Wait for a few seconds to observe the result
                System.Threading.Thread.Sleep(3000);

                // Capture and print the page title after login
                string pageTitle = driver.Title;
                Console.WriteLine("Page Title after login is: " + pageTitle);
            }
            catch (Exception e)
            {
                Console.WriteLine("An error occurred: " + e.Message);
            }
            finally
            {
                // Close the browser
                driver.Quit();
            }
        }
    }
}
