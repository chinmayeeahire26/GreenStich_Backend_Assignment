using System;
using OpenQA.Selenium;
using OpenQA.Selenium.Chrome;
using OpenQA.Selenium.Support.UI;

namespace LoginAutomation
{
    class Program
    {
        static void Main(string[] args)
        {
            // Initialize ChromeDriver
            IWebDriver driver = new ChromeDriver();

            try
            {
                // Navigate to the login page
                driver.Navigate().GoToUrl("https://example.com/login");

                // Wait for the page to load
                WebDriverWait wait = new WebDriverWait(driver, TimeSpan.FromSeconds(10));
                wait.Until(d => d.FindElement(By.Id("username")));

                // Enter username
                IWebElement usernameField = driver.FindElement(By.Id("username"));
                usernameField.SendKeys("testuser");

                // Enter password
                IWebElement passwordField = driver.FindElement(By.Id("password"));
                passwordField.SendKeys("password123");

                // Click login button
                IWebElement loginButton = driver.FindElement(By.Id("loginButton"));
                loginButton.Click();

                // Wait for login to complete, e.g., wait for a logout button or user profile element
                wait.Until(d => d.FindElement(By.Id("logoutButton")));

                Console.WriteLine("Login successful!");
            }
            catch (Exception ex)
            {
                Console.WriteLine("An error occurred: " + ex.Message);
            }
            finally
            {
                // Close the browser
                driver.Quit();
            }
        }
    }
}
