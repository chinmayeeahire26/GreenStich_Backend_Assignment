# Selenium WebDriver C# Login Automation

This project contains a Selenium WebDriver automation script in C# to perform login to an application.

## Project Structure

- LoginAutomation.sln: Solution file
- LoginAutomation/: Project folder
  - LoginAutomation.csproj: C# project file
  - Program.cs: Main program with Selenium WebDriver login script

## Prerequisites

- .NET SDK installed
- Selenium.WebDriver NuGet package
- ChromeDriver executable available in PATH or project folder

## Usage

Build and run the project to execute the login automation script.
