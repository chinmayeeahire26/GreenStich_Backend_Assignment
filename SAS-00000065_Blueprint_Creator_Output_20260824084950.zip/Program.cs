using System;
using OpenQA.Selenium;
using OpenQA.Selenium.Chrome;

namespace SeleniumSample
{
    class Program
    {
        static void Main(string[] args)
        {
            // Variables / Settings
            string url = "https://www.google.com";
            string searchBoxName = "q";
            string searchTerm = "Selenium WebDriver C#";

            // Initialize Chrome Driver
            IWebDriver driver = new ChromeDriver();

            try
            {
                // Navigate to URL
                driver.Navigate().GoToUrl(url);

                // Find the search box element by name
                IWebElement searchBox = driver.FindElement(By.Name(searchBoxName));

                // Enter search term
                searchBox.SendKeys(searchTerm);

                // Submit the search form
                searchBox.Submit();

                // Wait for results to load (simple wait)
                System.Threading.Thread.Sleep(3000);

                // Print the page title
                Console.WriteLine("Page Title is: " + driver.Title);
            }
            catch (Exception e)
            {
                Console.WriteLine("Test failed with exception: " + e.Message);
            }
            finally
            {
                // Close the browser
                driver.Quit();
            }
        }
    }
}
