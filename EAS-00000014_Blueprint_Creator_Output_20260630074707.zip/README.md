# Selenium WebDriver C# Automation Project

This project automates the login process for the application using Selenium WebDriver in C#.

## Project Structure

- src/
  - LoginAutomation/
    - LoginAutomation.csproj
    - Program.cs

## Prerequisites

- .NET SDK
- ChromeDriver executable in PATH or specify the path in the code
- Selenium.WebDriver NuGet package

## How to Run

1. Restore NuGet packages
2. Build the project
3. Run the executable

The automation script opens the login page, performs login steps, selects portfolio and requirements analysis, and logs out.