using NUnit.Framework;
using OpenQA.Selenium;
using OpenQA.Selenium.Chrome;
using System;

namespace AutomationTests
{
    [TestFixture]
    public class LoginTests
    {
        private IWebDriver driver;

        [SetUp]
        public void SetUp()
        {
            // Initialize ChromeDriver
            driver = new ChromeDriver();
            driver.Manage().Timeouts().ImplicitWait = TimeSpan.FromSeconds(10);
            driver.Manage().Window.Maximize();
        }

        [Test]
        public void LoginToApplication()
        {
            // Navigate to the login page
            driver.Navigate().GoToUrl("https://example.com/login");

            // Find username field and enter username
            var usernameField = driver.FindElement(By.Id("username"));
            usernameField.SendKeys("testuser");

            // Find password field and enter password
            var passwordField = driver.FindElement(By.Id("password"));
            passwordField.SendKeys("password123");

            // Find login button and click
            var loginButton = driver.FindElement(By.Id("loginButton"));
            loginButton.Click();

            // Assert that login was successful by checking for a logout button or user profile element
            var logoutButton = driver.FindElement(By.Id("logoutButton"));
            Assert.IsTrue(logoutButton.Displayed, "Logout button should be displayed after successful login.");
        }

        [TearDown]
        public void TearDown()
        {
            // Close the browser
            if (driver != null)
            {
                driver.Quit();
            }
        }
    }
}
