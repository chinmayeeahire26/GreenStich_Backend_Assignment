# Login Application Automation Project

This project contains Selenium WebDriver automation scripts in C# for logging into the application.
