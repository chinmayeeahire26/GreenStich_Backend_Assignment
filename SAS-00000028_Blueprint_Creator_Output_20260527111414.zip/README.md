# SAS-00000028_Blueprint_Creator_Output

This project contains a Selenium WebDriver automation script in C# for logging into the application at https://kairos-capgemini.azurewebsites.net/login.

## Project Structure

- src/: Contains the main C# source code.
- drivers/: Place the ChromeDriver executable here.

## Usage

1. Place the ChromeDriver executable in the drivers folder.
2. Build the project using .NET 6.0 SDK.
3. Run the executable.

## Notes

- Update the ChromeDriver version to match your installed Chrome browser.
- Ensure the XPath selectors are valid for the current web page structure.
