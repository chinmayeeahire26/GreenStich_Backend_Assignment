using OpenQA.Selenium;
using OpenQA.Selenium.Chrome;
using System;

namespace SeleniumAutomation
{
    class Program
    {
        static void Main(string[] args)
        {
            // Set the path to the ChromeDriver executable
            var chromeDriverService = ChromeDriverService.CreateDefaultService("./drivers");
            var options = new ChromeOptions();

            IWebDriver driver = new ChromeDriver(chromeDriverService, options);

            try
            {
                // Open the website
                driver.Navigate().GoToUrl("https://kairos-capgemini.azurewebsites.net/login");

                // Click on Your Image
                IWebElement yourImage = driver.FindElement(By.XPath("//body/app-root[1]/app-login[1]/div[1]/div[2]/div[1]/img[1]"));
                yourImage.Click();

                // Click on login
                IWebElement loginButton = driver.FindElement(By.XPath("/html[1]/body[1]/app-root[1]/app-login[1]/div[1]/div[1]/app-header[1]/div[1]/div[1]/nav[1]/a[4]/img[1]"));
                loginButton.Click();

                // Enter Username
                IWebElement usernameField = driver.FindElement(By.XPath("//input[@id='username']"));
                usernameField.SendKeys("shaik-raghiba.sulthana@capgemini-test.com");

                // Enter Password
                IWebElement passwordField = driver.FindElement(By.XPath("//input[@id='password']"));
                passwordField.SendKeys("Test@1234");

                // Click on Description of the image
                IWebElement descriptionImage = driver.FindElement(By.XPath("/html[1]/body[1]/div[2]/div[2]/div[1]/mat-dialog-container[1]/div[1]/div[1]/app-login-register-modal[1]/div[1]/div[1]/div[1]/form[1]/div[1]/button[1]/span[2]/img[1]"));
                descriptionImage.Click();

                // Click on Select Portfolio
                IWebElement selectPortfolio = driver.FindElement(By.XPath("/html[1]/body[1]/app-root[1]/app-home[1]/div[2]/div[1]/div[1]/div[1]/div[2]/div[1]/mat-form-field[1]/div[1]/div[2]/div[1]"));
                selectPortfolio.Click();

                // Click on option
                IWebElement option = driver.FindElement(By.XPath("//mat-option[@id='mat-option-4']"));
                option.Click();

                // Click on combobox
                IWebElement comboBox = driver.FindElement(By.XPath("/html[1]/body[1]/app-root[1]/app-home[1]/div[2]/div[1]/div[1]/div[1]/div[3]/div[1]/mat-form-field[1]/div[1]/div[2]/div[1]/mat-select[1]/div[1]/div[1]/span[1]"));
                comboBox.Click();

                // Click on Requirements Analysis
                IWebElement requirementsAnalysis = driver.FindElement(By.XPath("//span[contains(text(), 'Requirements Analysis')]");
                requirementsAnalysis.Click();

                // Click on tab
                IWebElement tab = driver.FindElement(By.XPath("//a[@id='mat-tab-link-6']"));
                tab.Click();

                // Click on Logout
                IWebElement logout = driver.FindElement(By.XPath("//a[contains(text(), 'Logout')]");
                logout.Click();
            }
            catch (Exception e)
            {
                Console.WriteLine(e.Message);
                Console.WriteLine(e.StackTrace);
            }
            finally
            {
                driver.Quit();
            }
        }
    }
}
