import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;

public class FlipkartLoginTest {

    public void flipkartLogin() {
        // Set path to the ChromeDriver
        System.setProperty("webdriver.chrome.driver", "path/to/chromedriver");

        // Initialize ChromeDriver
        WebDriver driver = new ChromeDriver();

        // Navigate to Flipkart login page
        driver.get("https://www.flipkart.com");

        // Close the initial popup
        WebElement closePopup = driver.findElement(By.xpath("//button[contains(text(), '✕')]"));
        closePopup.click();

        // Locate username and password fields
        WebElement usernameInput = driver.findElement(By.xpath("//input[@class='_2IX_2- VJZDxU']"));
        WebElement passwordInput = driver.findElement(By.xpath("//input[@type='password']"));

        // Enter credentials and submit
        usernameInput.sendKeys("your_username");
        passwordInput.sendKeys("your_password");

        WebElement loginButton = driver.findElement(By.xpath("//button[contains(@class, '_2KpZ6l _2HKlqd _3AWRsL')]"));
        loginButton.click();

        // Validate successful login (placeholder for validation logic)
        if (driver.getTitle().contains("Flipkart")) {
            System.out.println("Login successful");
        } else {
            System.out.println("Login failed");
        }

        // Close the browser
        driver.quit();
    }

    public static void main(String[] args) {
        FlipkartLoginTest test = new FlipkartLoginTest();
        test.flipkartLogin();
    }
}
