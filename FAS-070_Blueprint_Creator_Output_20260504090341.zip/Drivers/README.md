This folder is intended to hold WebDriver executables such as chromedriver.exe, geckodriver.exe, etc.
