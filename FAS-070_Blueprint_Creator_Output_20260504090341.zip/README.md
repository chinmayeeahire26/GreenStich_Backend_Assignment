# test Project

This is a Selenium WebDriver C# test project named 'test'.

## Structure
- Drivers: WebDriver executables
- Tests: Test scripts
- test.csproj: C# project file
- SampleTest.cs: Sample Selenium test script
