# Selenium Web Driver Project in C#

This project contains automated tests using Selenium Web Driver in C#.