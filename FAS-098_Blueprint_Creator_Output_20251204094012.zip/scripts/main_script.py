from selenium import webdriver
from selenium.webdriver.common.by import By
from selenium.webdriver.common.keys import Keys
import yaml

class ZeptoLogin:
    def __init__(self):
        # Load configurations
        with open('../config/config.yaml') as file:
            self.config = yaml.safe_load(file)

        self.driver = webdriver.Chrome()
        self.driver.implicitly_wait(10)

    def login_to_zepto(self):
        self.driver.get(self.config['zepto_url'])
        self.driver.find_element(By.ID, 'username').send_keys(self.config['username'])
        self.driver.find_element(By.ID, 'password').send_keys(self.config['password'])
        self.driver.find_element(By.ID, 'login_button').click()

    def close_browser(self):
        self.driver.quit()

if __name__ == '__main__':
    zepto_login = ZeptoLogin()
    zepto_login.login_to_zepto()
    # Additional automation tasks can be performed here
    zepto_login.close_browser()
