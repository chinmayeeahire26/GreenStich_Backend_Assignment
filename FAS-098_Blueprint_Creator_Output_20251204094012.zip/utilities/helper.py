import yaml

class UtilityHelper:
    @staticmethod
    def load_config(file_path):
        try:
            with open(file_path, 'r') as file:
                return yaml.safe_load(file)
        except Exception as e:
            print(f'Error loading configuration: {e}')
            return None

    @staticmethod
    def handle_exception(e):
        print(f'An error occurred: {e}')
