using System;
using OpenQA.Selenium;
using OpenQA.Selenium.Chrome;

namespace SeleniumSampleTest
{
    class Program
    {
        // Variables (Settings)
        static string url = "https://www.example.com";
        static string searchBoxId = "searchInput"; // Example element ID
        static string searchButtonId = "searchButton"; // Example element ID
        static string searchText = "Selenium WebDriver";

        static void Main(string[] args)
        {
            // Initialize ChromeDriver (make sure chromedriver.exe is in your PATH or project folder)
            IWebDriver driver = new ChromeDriver();
            try
            {
                // Navigate to URL
                driver.Navigate().GoToUrl(url);

                // Maximize browser window
                driver.Manage().Window.Maximize();

                // Find the search input box by ID and enter text
                IWebElement searchBox = driver.FindElement(By.Id(searchBoxId));
                searchBox.SendKeys(searchText);

                // Find the search button by ID and click it
                IWebElement searchButton = driver.FindElement(By.Id(searchButtonId));
                searchButton.Click();

                // Wait for some time to see results (not recommended for real tests, use explicit waits)
                System.Threading.Thread.Sleep(3000);

                // You can add assertions here to verify the test result (using NUnit, MSTest, etc.)
                Console.WriteLine("Test completed successfully.");
            }
            catch (NoSuchElementException e)
            {
                Console.WriteLine("Element not found: " + e.Message);
            }
            catch (Exception e)
            {
                Console.WriteLine("Test failed: " + e.Message);
            }
            finally
            {
                // Close the browser
                driver.Quit();
            }
        }
    }
}
