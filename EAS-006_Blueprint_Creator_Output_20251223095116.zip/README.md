# Project Structure

This directory contains the project structure for the automation script based on the blueprint guidelines.