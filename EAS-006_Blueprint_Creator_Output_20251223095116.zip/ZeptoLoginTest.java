import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;

public class ZeptoLoginTest {
    public void loginToZepto() {
        // Set the path to the ChromeDriver executable
        System.setProperty("webdriver.chrome.driver", "/path/to/chromedriver");

        // Initialize the WebDriver
        WebDriver driver = new ChromeDriver();

        try {
            // Navigate to Zepto login page
            driver.get("https://www.zepto.com/login");

            // Locate the username field and enter the username
            WebElement usernameField = driver.findElement(By.id("username"));
            usernameField.sendKeys("your_username");

            // Locate the password field and enter the password
            WebElement passwordField = driver.findElement(By.id("password"));
            passwordField.sendKeys("your_password");

            // Locate the login button and click it
            WebElement loginButton = driver.findElement(By.id("loginButton"));
            loginButton.click();

            // Additional verification can be added here

        } finally {
            // Close the browser
            driver.quit();
        }
    }
}