public class AjioLoginTest {
    public void myMethod() {
        System.out.println("hello github");
    }
}