using System;
using OpenQA.Selenium;
using OpenQA.Selenium.Chrome;

namespace SeleniumLoginExample
{
    class Program
    {
        static void Main(string[] args)
        {
            // Initialize ChromeDriver
            using (IWebDriver driver = new ChromeDriver())
            {
                // Navigate to the login page
                driver.Navigate().GoToUrl("https://example.com/login");

                // Find username and password fields and enter credentials
                IWebElement usernameField = driver.FindElement(By.Name("username"));
                IWebElement passwordField = driver.FindElement(By.Name("password"));

                usernameField.SendKeys("testuser");
                passwordField.SendKeys("testpassword");

                // Find and click the login button
                IWebElement loginButton = driver.FindElement(By.CssSelector("button[type='submit']"));
                loginButton.Click();

                // Wait for a few seconds to observe the result
                System.Threading.Thread.Sleep(5000);

                // Close the browser
                driver.Quit();
            }
        }
    }
}
