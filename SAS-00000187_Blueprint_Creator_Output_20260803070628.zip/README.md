# Selenium Login Example

This is a simple C# Console Application demonstrating Selenium WebDriver automation for a login page.

## Prerequisites
- .NET 6.0 SDK or later
- Chrome browser installed

## Setup
1. Restore NuGet packages:
   ```
   dotnet restore
   ```
2. Run the application:
   ```
   dotnet run
   ```

The program will open Chrome, navigate to a sample login page, enter credentials, and submit the form.

## Notes
- Update the URL and element selectors in Program.cs to match your actual login page.
- Ensure ChromeDriver version matches your Chrome browser version.
