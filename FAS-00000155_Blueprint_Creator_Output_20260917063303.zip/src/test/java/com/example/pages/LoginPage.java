package com.example.pages;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

/**
 * Generic login page object.
 * Update locators to match your application's login page.
 */
public class LoginPage {

    private final WebDriver driver;
    private final WebDriverWait wait;

    // Common login locators (adjust as needed)
    private final By usernameInput = By.cssSelector("input[name='username'], input[type='email'], #username, #email");
    private final By passwordInput = By.cssSelector("input[name='password'], input[type='password'], #password");
    private final By submitButton = By.cssSelector("button[type='submit'], input[type='submit'], #login, #signIn");

    // A generic post-login indicator (adjust as needed)
    private final By postLoginIndicator = By.cssSelector("[data-test='dashboard'], [data-testid='dashboard'], #dashboard, .dashboard, .account, .profile");

    public LoginPage(WebDriver driver, WebDriverWait wait) {
        this.driver = driver;
        this.wait = wait;
    }

    public void open(String baseUrl) {
        driver.get(baseUrl);
    }

    /** methodName: loginWithValidCredentials */
    public void loginWithValidCredentials(String username, String password) {
        wait.until(ExpectedConditions.presenceOfElementLocated(usernameInput)).clear();
        driver.findElement(usernameInput).sendKeys(username);

        wait.until(ExpectedConditions.presenceOfElementLocated(passwordInput)).clear();
        driver.findElement(passwordInput).sendKeys(password);

        wait.until(ExpectedConditions.elementToBeClickable(submitButton)).click();
    }

    public boolean isLoggedIn() {
        try {
            wait.until(ExpectedConditions.presenceOfElementLocated(postLoginIndicator));
            return true;
        } catch (Exception e) {
            return false;
        }
    }
}
