package com.example.tests;

import com.example.framework.Config;
import com.example.framework.DriverFactory;
import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeEach;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.support.ui.WebDriverWait;

import java.time.Duration;

public abstract class BaseTest {

    protected WebDriver driver;
    protected WebDriverWait wait;
    protected Config config;

    @BeforeEach
    void setUp() {
        config = Config.load("config.properties");
        driver = DriverFactory.createDriver(config);

        int explicitWaitSeconds = config.getIntOrDefault("explicitWaitSeconds", 15);
        wait = new WebDriverWait(driver, Duration.ofSeconds(explicitWaitSeconds));
    }

    @AfterEach
    void tearDown() {
        if (driver != null) {
            driver.quit();
        }
    }
}
