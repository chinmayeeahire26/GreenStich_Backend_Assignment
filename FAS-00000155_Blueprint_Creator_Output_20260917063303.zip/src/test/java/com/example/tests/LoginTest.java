package com.example.tests;

import com.example.pages.LoginPage;
import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Test;

public class LoginTest extends BaseTest {

    /** methodName: generateLoginWithValidCredentials */
    @Test
    void generateLoginWithValidCredentials() {
        String baseUrl = config.get("baseUrl");
        String username = config.get("username");
        String password = config.get("password");

        LoginPage loginPage = new LoginPage(driver, wait);
        loginPage.open(baseUrl);
        loginPage.loginWithValidCredentials(username, password);

        Assertions.assertTrue(
                loginPage.isLoggedIn(),
                "Expected user to be logged in after submitting valid credentials. " +
                        "Update LoginPage locators/post-login indicator to match your AUT if this fails."
        );
    }
}
