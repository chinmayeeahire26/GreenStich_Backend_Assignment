package com.example.framework;

import java.io.IOException;
import java.io.InputStream;
import java.util.Properties;

public final class Config {

    private final Properties properties;

    private Config(Properties properties) {
        this.properties = properties;
    }

    public static Config load(String resourcePath) {
        Properties props = new Properties();
        try (InputStream is = Config.class.getClassLoader().getResourceAsStream(resourcePath)) {
            if (is == null) {
                throw new IllegalStateException("Config resource not found on classpath: " + resourcePath);
            }
            props.load(is);
        } catch (IOException e) {
            throw new RuntimeException("Failed to load config: " + resourcePath, e);
        }
        return new Config(props);
    }

    public String get(String key) {
        String val = properties.getProperty(key);
        if (val == null) {
            throw new IllegalStateException("Missing required config key: " + key);
        }
        return val;
    }

    public String getOrDefault(String key, String defaultValue) {
        return properties.getProperty(key, defaultValue);
    }

    public int getIntOrDefault(String key, int defaultValue) {
        String v = properties.getProperty(key);
        if (v == null) return defaultValue;
        return Integer.parseInt(v.trim());
    }
}
