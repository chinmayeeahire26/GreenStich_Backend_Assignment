# Login Automation (Selenium + JUnit 5)

## What this project contains
Automated test case: **Generate login with valid credentials**.

## How to run
```bash
mvn test
```

## Configuration
Edit: `src/test/resources/config.properties`
- `baseUrl`
- `username`
- `password`
- `browser` (chrome|firefox)
- `headless` (true|false)

> Note: The sample login page object (`LoginPage`) is written to be easily adaptable to your AUT by updating the locators.
