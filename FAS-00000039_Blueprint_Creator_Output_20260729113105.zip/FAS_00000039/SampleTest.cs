using System;
using OpenQA.Selenium;
using OpenQA.Selenium.Chrome;
using OpenQA.Selenium.Support.UI;

namespace FAS_00000039
{
    class SampleTest
    {
        static void Main(string[] args)
        {
            IWebDriver driver = new ChromeDriver();
            try
            {
                driver.Navigate().GoToUrl("https://www.example.com");
                WebDriverWait wait = new WebDriverWait(driver, TimeSpan.FromSeconds(10));
                wait.Until(d => d.Title.Contains("Example Domain"));
                Console.WriteLine("Page title is: " + driver.Title);
                // Add more test steps here
            }
            catch (Exception ex)
            {
                Console.WriteLine("Test failed: " + ex.Message);
            }
            finally
            {
                driver.Quit();
            }
        }
    }
}
