
using System;
using OpenQA.Selenium;
using OpenQA.Selenium.Chrome;

class FlipkartLoginTest {
    static void Main() {
        // Initialize the Chrome Driver
        using (IWebDriver driver = new ChromeDriver()) {
            // Go to the Flipkart login page
            driver.Navigate().GoToUrl("https://www.flipkart.com/account/login");

            // Find the username and password fields and enter the credentials
            driver.FindElement(By.XPath("//input[@class='_2IX_2- VJZDxU']")).SendKeys("your_username");
            driver.FindElement(By.XPath("//input[@type='password']")).SendKeys("your_password");

            // Click the login button
            driver.FindElement(By.XPath("//button[@class='_2KpZ6l _2HKlqd _3AWRsL']")).Click();

            // Wait for some time to see the result
            System.Threading.Thread.Sleep(5000);

            // Close the browser
            driver.Quit();
        }
    }
}
