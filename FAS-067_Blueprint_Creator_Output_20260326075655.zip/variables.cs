public class Variables {
    public static string username = "test_user";
    public static string password = "secure_password";
}