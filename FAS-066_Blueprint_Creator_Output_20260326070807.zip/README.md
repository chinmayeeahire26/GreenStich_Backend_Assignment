# Selenium WebDriver C# Project

This project is designed to automate login functionality for Flipkart using Selenium WebDriver and C#.

## Project Structure

- **src/**: Contains the source code for the test scripts.
- **lib/**: Contains external libraries and dependencies.
- **settings/**: Contains configuration settings.
- **tests/**: Contains test scripts.
- **variables/**: Contains variable definitions.
