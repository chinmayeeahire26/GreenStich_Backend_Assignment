using System;
using OpenQA.Selenium;
using OpenQA.Selenium.Chrome;

namespace FlipkartAutomation
{
    class Program
    {
        static void Main(string[] args)
        {
            // Initialize the Chrome driver
            IWebDriver driver = new ChromeDriver();

            try
            {
                // Navigate to Flipkart
                driver.Navigate().GoToUrl("https://www.flipkart.com");

                // Maximize the browser window
                driver.Manage().Window.Maximize();

                // Close the login popup
                IWebElement closeLoginPopup = driver.FindElement(By.XPath("//button[contains(text(),'✕')]");
                closeLoginPopup.Click();

                // Click on the login link
                IWebElement loginLink = driver.FindElement(By.XPath("//a[contains(text(),'Login')]");
                loginLink.Click();

                // Enter username
                IWebElement usernameField = driver.FindElement(By.XPath("//input[@class='_2IX_2- VJZDxU']");
                usernameField.SendKeys("your_username");

                // Enter password
                IWebElement passwordField = driver.FindElement(By.XPath("//input[@type='password']");
                passwordField.SendKeys("your_password");

                // Click on the login button
                IWebElement loginButton = driver.FindElement(By.XPath("//button[@type='submit']");
                loginButton.Click();

                // Wait for a few seconds to observe the result
                System.Threading.Thread.Sleep(5000);
            }
            catch (Exception e)
            {
                Console.WriteLine("An error occurred: " + e.Message);
            }
            finally
            {
                // Close the browser
                driver.Quit();
            }
        }
    }
}
