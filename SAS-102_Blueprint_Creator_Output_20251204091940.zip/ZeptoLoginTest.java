package automation;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;

public class ZeptoLoginTest {

    // Method to automate Zepto login
    public void loginToZepto() {
        // Set the path for the ChromeDriver executable
        System.setProperty("webdriver.chrome.driver", "/path/to/chromedriver");

        // Initialize WebDriver instance
        WebDriver driver = new ChromeDriver();

        try {
            // Navigate to the Zepto login page
            driver.get("https://www.zepto.com/login");

            // Maximize the browser window
            driver.manage().window().maximize();

            // Locate the login fields and input credentials
            WebElement emailField = driver.findElement(By.id("email"));
            WebElement passwordField = driver.findElement(By.id("password"));
            WebElement loginButton = driver.findElement(By.id("loginButton"));

            emailField.sendKeys("your-email@example.com");
            passwordField.sendKeys("your-secure-password");

            // Click the login button
            loginButton.click();

            // Wait for login to complete (generic example - real implementation would use WebDriverWait)
            Thread.sleep(5000);

            // Confirm login success (example - checking presence of a specific element)
            WebElement userProfile = driver.findElement(By.id("profileIcon"));
            if (userProfile.isDisplayed()) {
                System.out.println("Login successful.");
            } else {
                System.out.println("Login failed.");
            }
        } catch (Exception e) {
            e.printStackTrace();
        } finally {
            // Quit the browser session
            driver.quit();
        }
    }

    public static void main(String[] args) {
        ZeptoLoginTest loginTest = new ZeptoLoginTest();
        loginTest.loginToZepto();
    }
}