# Project: Zepto Login Automation

This project contains the folder structure and scripts required for automating the login functionality for a Zepto application. It strictly follows the guidelines and scripts outlined in the blueprint instructions.