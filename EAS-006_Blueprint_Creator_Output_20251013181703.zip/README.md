# Project Overview

Automation Testing Project for Zepto Login functionality.

## Project Structure

- **src**: Contains source code and core libraries.
- **tests**: Includes test scripts.
- **config**: Holds configuration files.
- **dependencies**: Manages external dependencies.

See details in the blueprint guidelines.