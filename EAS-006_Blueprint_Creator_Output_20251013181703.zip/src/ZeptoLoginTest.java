public class ZeptoLoginTest {

    public void loginToZepto() {
        // Launch web browser
        WebDriver driver = new ChromeDriver();

        // Open Zepto login page
        driver.get("https://www.zepto.com/login");

        // Enter user credentials
        WebElement usernameField = driver.findElement(By.name("username"));
        usernameField.sendKeys("test_user");
        WebElement passwordField = driver.findElement(By.name("password"));
        passwordField.sendKeys("password123");

        // Click login button
        WebElement loginButton = driver.findElement(By.name("login"));
        loginButton.click();

        // Verify login successful
        String expectedUrl = "https://www.zepto.com/home";
        String actualUrl = driver.getCurrentUrl();
        if (expectedUrl.equals(actualUrl)) {
            System.out.println("Login successful.");
        } else {
            System.out.println("Login failed.");
        }

        // Close the browser
        driver.quit();
    }
}