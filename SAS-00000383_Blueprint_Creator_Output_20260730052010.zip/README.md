# Login Automation Project

This project contains automation scripts for logging into the application using Selenium WebDriver, Java, TestNG, and Cucumber.

## Project Structure

- src/main/java: Main Java source code (if any)
- src/test/java: Test Java source code (step definitions, runners)
- src/test/resources: Feature files and test resources
- testng.xml: TestNG configuration file

## How to Run

Use TestNG to run the tests via the testng.xml configuration file.

