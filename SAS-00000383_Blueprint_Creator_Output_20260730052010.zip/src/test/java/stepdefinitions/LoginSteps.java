package stepdefinitions;

import io.cucumber.java.en.*;

public class LoginSteps {

    @Given("User is on the login page")
    public void user_is_on_the_login_page() {
        // Code to navigate to login page
    }

    @When("User enters valid username and password")
    public void user_enters_valid_username_and_password() {
        // Code to enter username and password
    }

    @When("User clicks on the login button")
    public void user_clicks_on_the_login_button() {
        // Code to click login button
    }

    @Then("User should be redirected to the homepage")
    public void user_should_be_redirected_to_the_homepage() {
        // Code to verify homepage is displayed
    }
}
