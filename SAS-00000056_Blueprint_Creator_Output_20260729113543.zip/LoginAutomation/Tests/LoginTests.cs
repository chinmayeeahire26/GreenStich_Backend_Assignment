using NUnit.Framework;
using OpenQA.Selenium;
using OpenQA.Selenium.Chrome;
using System;

namespace LoginAutomation.Tests
{
    public class LoginTests
    {
        private IWebDriver driver;
        private string loginUrl = "https://example.com/login";
        private string username = "testuser";
        private string password = "password123";

        [SetUp]
        public void Setup()
        {
            driver = new ChromeDriver();
            driver.Manage().Timeouts().ImplicitWait = TimeSpan.FromSeconds(10);
        }

        [Test]
        public void Login_WithValidCredentials_ShouldSucceed()
        {
            driver.Navigate().GoToUrl(loginUrl);

            var usernameField = driver.FindElement(By.Id("username"));
            var passwordField = driver.FindElement(By.Id("password"));
            var loginButton = driver.FindElement(By.Id("loginButton"));

            usernameField.SendKeys(username);
            passwordField.SendKeys(password);
            loginButton.Click();

            // Assert successful login by checking for a logout button or user profile element
            var logoutButton = driver.FindElement(By.Id("logoutButton"));
            Assert.IsTrue(logoutButton.Displayed, "Logout button should be displayed after successful login.");
        }

        [TearDown]
        public void TearDown()
        {
            driver.Quit();
        }
    }
}
