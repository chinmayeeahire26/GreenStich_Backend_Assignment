import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;

public class LoginTest {
    private WebDriver driver;

    @BeforeTest
    public void setUp() {
        System.setProperty("webdriver.chrome.driver", "/path/to/chromedriver");
        driver = new ChromeDriver();
        driver.manage().window().maximize();
    }

    @Test
    public void loginToFlipkart() {
        driver.get("https://www.flipkart.com");
        driver.findElement(By.xpath("//input[@class='_2IX_2- VJZDxU']")).sendKeys("your_email@example.com");
        driver.findElement(By.xpath("//input[@type='password']")).sendKeys("your_password");
        driver.findElement(By.xpath("//button[contains(text(),'Login')]")).click();
    }

    @AfterTest
    public void tearDown() {
        driver.quit();
    }
}