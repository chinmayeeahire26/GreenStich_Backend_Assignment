import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;

public class ZomatoLoginTest {

    public void loginToZomato() {
        System.setProperty("webdriver.chrome.driver", "path/to/chromedriver");
        WebDriver driver = new ChromeDriver();
        driver.get("https://www.zomato.com");

        WebElement loginButton = driver.findElement(By.id("login-button-id"));
        loginButton.click();

        WebElement emailField = driver.findElement(By.id("email-field-id"));
        emailField.sendKeys("your-email@example.com");

        WebElement passwordField = driver.findElement(By.id("password-field-id"));
        passwordField.sendKeys("your-password");

        WebElement submitButton = driver.findElement(By.id("submit-button-id"));
        submitButton.click();

        // Add assertions to verify login success

        driver.quit();
    }
}