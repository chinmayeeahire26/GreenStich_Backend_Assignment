# Zomata Automation Project

This project contains automation scripts for testing the login functionality of Zomata.