// Test script for validating login functionality
const { expect } = require('chai');
const loginScript = require('../src/scripts/loginToFlipcart');

describe('Flipkart Login Test', function() {
    this.timeout(15000);
    it('should login successfully', async () => {
        const result = await loginScript();
        expect(result).to.be.true;
    });
});