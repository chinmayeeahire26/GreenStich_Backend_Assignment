// Configuration settings for the Flipkart login automation
module.exports = {
    user: 'yourUsername',
    pass: 'yourPassword',
    timeout: 10000
};