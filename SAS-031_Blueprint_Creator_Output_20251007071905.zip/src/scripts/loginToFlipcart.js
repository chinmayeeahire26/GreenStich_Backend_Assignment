// This script automates the login process to Flipkart using Selenium WebDriver
const { Builder, By, until } = require('selenium-webdriver');

async function login() {
    let driver = await new Builder().forBrowser('firefox').build();
    try {
        await driver.get('https://www.flipkart.com');
        await driver.findElement(By.name('username')).sendKeys('yourUsername');
        await driver.findElement(By.name('password')).sendKeys('yourPassword');
        await driver.findElement(By.css('button[type=submit]')).click();
    } finally {
        await driver.quit();
    }
}

login().catch(console.error);