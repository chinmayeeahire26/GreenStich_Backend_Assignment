using System;
using OpenQA.Selenium;
using OpenQA.Selenium.Chrome;

namespace SeleniumTests
{
    public class SampleTest
    {
        public static void Main(string[] args)
        {
            IWebDriver driver = new ChromeDriver();
            driver.Navigate().GoToUrl("https://www.example.com");
            Console.WriteLine("Page title is: " + driver.Title);
            driver.Quit();
        }
    }
}