# EAS-017 Blueprint Creator Output

This directory contains the project structure for the Flipkart login automation script.